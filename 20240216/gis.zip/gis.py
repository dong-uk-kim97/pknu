"""
import folium
from folium.plugins import HeatMap

m = folium.Map(location=[35.89747, 127.092337], zoom_start=13)

m.save("index.html")
"""
import folium
import folium as g
import webbrowser
import time
import base64


m = folium.Map(location=[35.1347223, 129.107886],
               zoom_start=12)

latlon=[
    [35.248905, 129.095482],
    [35.240931, 129.1093]
]

pic = base64.b64encode(open('sum.jpg', 'rb').read()).decode()
image_tag = '<img src="data:image/jpeg;base64,{}">'.format(pic)
iframe = folium.IFrame(image_tag, width=230, height=100)
popup = folium.Popup(iframe, max_width=650)

for i in range(len(latlon)):
    folium.Marker(latlon[i],
                  popup = popup,
                  tooltip="부경대학교").add_to(m)


m.save('filename.html')
webbrowser.open_new_tab('filename.html')
